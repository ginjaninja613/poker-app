import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Button,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';

export default function TournamentDetailScreen({ route, navigation }) {
  const { tournament: initialTournament, casinoName, casinoId } = route.params;
  const [tournament, setTournament] = useState(initialTournament);

  const [canEdit, setCanEdit] = useState(false);

  useEffect(() => {
    const checkAccess = async () => {
      const role = await AsyncStorage.getItem('role');
      const assignedCasino = await AsyncStorage.getItem('casinoId');

      if (role === 'staff' && assignedCasino === casinoId) {
        setCanEdit(true);
      }
    };

    checkAccess();
  }, []);

  useFocusEffect(
    React.useCallback(() => {
      const fetchTournament = async () => {
        try {
          const token = await AsyncStorage.getItem('token');
          const res = await fetch(
            `http://192.168.0.180:5000/api/casinos/${casinoId}/tournaments/${tournament._id}`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
          const updated = await res.json();
          if (!res.ok) throw new Error(updated.error || 'Failed to reload tournament');

          setTournament(updated);

        } catch (err) {
          console.error('🔄 Error refreshing tournament:', err.message);
        }
      };

      fetchTournament();
    }, [casinoId, tournament._id])
  );

  const handleDelete = () => {
    Alert.alert('Confirm Delete', 'Are you sure you want to delete this tournament?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            const token = await AsyncStorage.getItem('token');
            const response = await fetch(
              `http://192.168.0.180:5000/api/casinos/${casinoId}/tournaments/${tournament._id}`,
              {
                method: 'DELETE',
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              }
            );

            const data = await response.json();
            if (!response.ok) throw new Error(data.error || 'Delete failed');

            Alert.alert('Success', 'Tournament deleted');
            navigation.goBack();
          } catch (err) {
            Alert.alert('Error', err.message);
          }
        },
      },
    ]);
  };

  const handleEdit = () => {
    navigation.navigate('EditTournament', {
      tournamentId: tournament._id,
      casinoId: casinoId,
    });
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>{tournament.name}</Text>
      <Text style={styles.subheader}>@ {casinoName}</Text>

      <Text style={styles.item}>🎯 Buy-In: £{tournament.buyIn}</Text>
      <Text style={styles.item}>💸 Rake: £{tournament.rake}</Text>
      <Text style={styles.item}>🕒 Start: {new Date(tournament.date).toLocaleString()}</Text>

      {tournament.gameType && <Text style={styles.item}>🎲 Game Type: {tournament.gameType}</Text>}
      {typeof tournament.startingChips && <Text style={styles.item}>🪙 Starting Chips: {tournament.startingChips}</Text>}
      {tournament.prizePool && <Text style={styles.item}>🎁 Prize Pool: £{tournament.prizePool}</Text>}
      {typeof tournament.lateRegistrationLevels && (
        <Text style={styles.item}>⏳ Late Registration: {tournament.lateRegistrationLevels} levels</Text>
      )}
      {tournament.reentriesAllowed >= 0 && (
        <Text style={styles.item}>🔁 Re-Entries Allowed: {tournament.reentriesAllowed}</Text>
      )}
      {tournament.isBounty && tournament.bountyAmount && (
        <Text style={styles.item}>🏆 Bounty: £{tournament.bountyAmount}</Text>
      )}

      {tournament.structure?.length > 0 && (
        <View style={styles.structureBox}>
          <Text style={styles.sectionHeader}>📋 Blind Structure</Text>
          <View style={styles.tableHeader}>
            <Text style={[styles.tableCell, styles.headerCell]}>Small</Text>
            <Text style={[styles.tableCell, styles.headerCell]}>Big</Text>
            <Text style={[styles.tableCell, styles.headerCell]}>Duration</Text>
          </View>
          {tournament.structure.map((entry, index) => {
            const isBreak = entry.level?.toLowerCase?.().includes('break');
            return (
              <View key={index} style={[styles.tableRow, isBreak && styles.breakRow]}>
                {isBreak ? (
                  <>
                    <Text style={[styles.tableCell, styles.breakCell]}>Break</Text>
                    <Text style={styles.tableCell}>–</Text>
                    <Text style={styles.tableCell}>{entry.duration} min</Text>
                  </>
                ) : (
                  <>
                    <Text style={styles.tableCell}>{entry.smallBlind ?? '-'}</Text>
                    <Text style={styles.tableCell}>{entry.bigBlind ?? '-'}</Text>
                    <Text style={styles.tableCell}>{entry.duration} min</Text>
                  </>
                )}
              </View>
            );
          })}
        </View>
      )}

      {canEdit && (
        <View style={styles.buttonRow}>
          <Button title="✏️ Edit" onPress={handleEdit} />
          <View style={{ width: 10 }} />
          <Button title="🗑️ Delete" color="#c00" onPress={handleDelete} />
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#f6f6f6',
  },
  header: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  subheader: {
    fontSize: 14,
    color: '#555',
    marginBottom: 12,
  },
  item: {
    fontSize: 14,
    marginVertical: 2,
  },
  structureBox: {
    marginTop: 20,
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  tableHeader: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderColor: '#ccc',
    marginBottom: 4,
    paddingBottom: 4,
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 6,
  },
  tableCell: {
    flex: 1,
    fontSize: 13,
    textAlign: 'center',
  },
  headerCell: {
    fontWeight: 'bold',
  },
  breakRow: {
    backgroundColor: '#fce4ec',
  },
  breakCell: {
    flex: 1,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#c62828',
  },
  buttonRow: {
    flexDirection: 'row',
    marginTop: 20,
    justifyContent: 'center',
  },
});
