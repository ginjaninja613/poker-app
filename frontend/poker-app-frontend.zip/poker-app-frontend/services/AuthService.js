import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = 'http://192.168.0.180:5000/api/auth'; // use LAN IP for real device testing

export async function login(email, password) {
  const res = await fetch(`${API_URL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Login failed');

  await AsyncStorage.setItem('token', data.token);
  await AsyncStorage.setItem('role', data.role);

  return data;
}

export async function logout() {
  await AsyncStorage.removeItem('token');
  await AsyncStorage.removeItem('role');
}

export async function getToken() {
  return await AsyncStorage.getItem('token');
}

export async function getUserRole() {
  return await AsyncStorage.getItem('role');
}
