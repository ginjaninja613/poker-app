const express = require('express');
const Tournament = require('../models/Tournament');
const Casino = require('../models/Casino');
const auth = require('../middleware/auth');
const requireStaff = require('../middleware/requireStaff');
const router = express.Router();

// Staff must be assigned to the casino (unless admin)
function ensureAssignedOrAdmin(req, casinoId) {
  if (!req.user) return false;
  if (req.user.role === 'admin') return true;
  return req.user.assignedCasinoIds?.includes(String(casinoId));
}

// Public: list tournaments with optional filters: casinoId, dateFrom, dateTo, status
router.get('/', async (req, res) => {
  try {
    const { casinoId, dateFrom, dateTo, status } = req.query;
    const q = {};
    if (casinoId) q.casinoId = casinoId;
    if (status) q.status = status;
    if (dateFrom || dateTo) {
      q.dateTimeUTC = {};
      if (dateFrom) q.dateTimeUTC.$gte = new Date(dateFrom);
      if (dateTo) q.dateTimeUTC.$lte = new Date(dateTo);
    }
    const items = await Tournament.find(q).sort({ dateTimeUTC: 1 }).lean();
    res.json(items);
  } catch {
    res.status(500).json({ error: 'Failed to list tournaments' });
  }
});

// Public: get one tournament
router.get('/:id', async (req, res) => {
  try {
    const item = await Tournament.findById(req.params.id).lean();
    if (!item) return res.status(404).json({ error: 'Tournament not found' });
    res.json(item);
  } catch {
    res.status(500).json({ error: 'Failed to get tournament' });
  }
});

// Staff: create tournament
router.post('/', auth, requireStaff, async (req, res) => {
  try {
    const data = req.body;
    if (!data.casinoId) return res.status(400).json({ error: 'casinoId is required' });
    if (!ensureAssignedOrAdmin(req, data.casinoId)) {
      return res.status(403).json({ error: 'Not assigned to this casino' });
    }
    const casino = await Casino.findById(data.casinoId).lean();
    if (!casino) return res.status(400).json({ error: 'Casino does not exist' });

    const created = await Tournament.create(data);
    res.status(201).json(created);
  } catch {
    res.status(500).json({ error: 'Failed to create tournament' });
  }
});

// Staff: update tournament
router.put('/:id', auth, requireStaff, async (req, res) => {
  try {
    const existing = await Tournament.findById(req.params.id);
    if (!existing) return res.status(404).json({ error: 'Tournament not found' });
    if (!ensureAssignedOrAdmin(req, existing.casinoId)) {
      return res.status(403).json({ error: 'Not assigned to this casino' });
    }
    Object.assign(existing, req.body); // partial update
    const saved = await existing.save();
    res.json(saved);
  } catch {
    res.status(500).json({ error: 'Failed to update tournament' });
  }
});

// Staff: delete tournament
router.delete('/:id', auth, requireStaff, async (req, res) => {
  try {
    const existing = await Tournament.findById(req.params.id);
    if (!existing) return res.status(404).json({ error: 'Tournament not found' });
    if (!ensureAssignedOrAdmin(req, existing.casinoId)) {
      return res.status(403).json({ error: 'Not assigned to this casino' });
    }
    await existing.deleteOne();
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: 'Failed to delete tournament' });
  }
});

module.exports = router;
