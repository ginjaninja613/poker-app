import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  ScrollView,
  Alert,
  TouchableOpacity,
  Switch,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { useNavigation, useRoute } from '@react-navigation/native';
import axios from 'axios';

export default function EditTournamentScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const { tournamentId, casinoId } = route.params;

  const [name, setName] = useState('');
  const [buyIn, setBuyIn] = useState('');
  const [rake, setRake] = useState('');
  const [date, setDate] = useState(new Date());
  const [isPickerVisible, setPickerVisible] = useState(false);

  const [startingChips, setStartingChips] = useState('');
  const [gameType, setGameType] = useState('No Limit Hold’em');
  const [prizePool, setPrizePool] = useState('');
  const [lateRegistrationLevels, setLateRegistrationLevels] = useState('');
  const [reentriesAllowed, setReentriesAllowed] = useState('');
  const [isBounty, setIsBounty] = useState(false);
  const [bountyAmount, setBountyAmount] = useState('');

  const [structure, setStructure] = useState([]);
  const [newLevel, setNewLevel] = useState('');
  const [newDuration, setNewDuration] = useState('');
  const [insertIndex, setInsertIndex] = useState('');

  useEffect(() => {
    const fetchTournament = async () => {
      try {
        const token = await AsyncStorage.getItem('token');
        const res = await axios.get(
          `http://192.168.0.180:5000/api/casinos/${casinoId}/tournaments/${tournamentId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const data = res.data;
        setName(data.name);
        setBuyIn(data.buyIn?.toString() || '');
        setRake(data.rake?.toString() || '');
        setDate(data.date ? new Date(data.date) : new Date());

        setStartingChips(data.startingChips?.toString() || '');
        setGameType(data.gameType || '');
        setPrizePool(data.prizePool?.toString() || '');
        setLateRegistrationLevels(data.lateRegistrationLevels?.toString() || '');
        setReentriesAllowed(data.reentriesAllowed?.toString() || '');
        setIsBounty(data.isBounty || false);
        setBountyAmount(data.bountyAmount?.toString() || '');
        setStructure(data.structure || []);
      } catch (err) {
        console.error('❌ Error loading tournament:', err);
        Alert.alert('Error', 'Failed to load tournament');
      }
    };

    fetchTournament();
  }, [casinoId, tournamentId]);

  const handleConfirm = (selectedDate) => {
    setDate(selectedDate);
    setPickerVisible(false);
  };

  const removeLevel = (index) => {
    const updated = [...structure];
    updated.splice(index, 1);
    setStructure(updated);
  };

  const insertLevel = () => {
    if (!newLevel || !newDuration) {
      Alert.alert('Error', 'Enter both level and duration');
      return;
    }

    const duration = parseInt(newDuration);
    let newEntry;

    if (newLevel.trim().toLowerCase() === 'break') {
      newEntry = { level: 'Break', duration };
    } else {
      const match = newLevel.match(/^(\d+)\s*\/\s*(\d+)$/);
      if (!match) {
        Alert.alert('Format error', 'Use format like 100/200 or enter "Break"');
        return;
      }
      const smallBlind = parseInt(match[1]);
      const bigBlind = parseInt(match[2]);
      newEntry = { smallBlind, bigBlind, duration };
    }

    const index = insertIndex === ''
      ? structure.length
      : Math.max(0, Math.min(parseInt(insertIndex) - 1, structure.length));

    const updated = [...structure];
    updated.splice(index, 0, newEntry);
    setStructure(updated);
    setNewLevel('');
    setNewDuration('');
    setInsertIndex('');
  };

  const handleSubmit = async () => {
    const tournament = {
      name,
      buyIn: Number(buyIn),
      rake: Number(rake),
      date,
      structure,
      startingChips: Number(startingChips),
      gameType,
      prizePool: Number(prizePool),
      lateRegistrationLevels: Number(lateRegistrationLevels),
      reentriesAllowed: Number(reentriesAllowed),
      isBounty,
      bountyAmount: isBounty ? Number(bountyAmount) : undefined,
    };

    console.log('🚀 Submitting update:', tournament);

    try {
      const token = await AsyncStorage.getItem('token');

      const response = await fetch(
        `http://192.168.0.180:5000/api/casinos/${casinoId}/tournaments/${tournamentId}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(tournament),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        console.log('❌ Server response:', response.status, data);
        throw new Error(data.error || 'Failed to update tournament');
      }

      Alert.alert('Success', 'Tournament updated!');
      navigation.goBack();
    } catch (err) {
      console.error('❌ Error from fetch:', err.message);
      Alert.alert('Error', err.message);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.section}>🎯 Basic Info</Text>
      <TextInput style={styles.input} placeholder="Tournament Name" value={name} onChangeText={setName} />
      <TextInput style={styles.input} placeholder="Buy-In (£)" value={buyIn} onChangeText={setBuyIn} keyboardType="numeric" />
      <TextInput style={styles.input} placeholder="Rake (£)" value={rake} onChangeText={setRake} keyboardType="numeric" />

      <TouchableOpacity onPress={() => setPickerVisible(true)} style={styles.input}>
        <Text>Start Time: {date.toLocaleString()}</Text>
      </TouchableOpacity>
      <DateTimePickerModal
        isVisible={isPickerVisible}
        mode="datetime"
        date={date}
        onConfirm={handleConfirm}
        onCancel={() => setPickerVisible(false)}
      />

      <Text style={styles.section}>🧮 Structure</Text>
      <TextInput style={styles.input} placeholder='Level (e.g. "100/200" or "Break")' value={newLevel} onChangeText={setNewLevel} />
      <TextInput style={styles.input} placeholder="Duration (min)" value={newDuration} onChangeText={setNewDuration} keyboardType="numeric" />
      <TextInput style={styles.input} placeholder="Insert at position (optional)" value={insertIndex} onChangeText={setInsertIndex} keyboardType="numeric" />
      <Button title="Insert Level" onPress={insertLevel} />

      {structure.length > 0 && (
        <View style={styles.structureList}>
          {structure.map((s, i) => (
            <View key={i} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 5 }}>
              <Text style={{ flex: 1 }}>
                {s.level || `${s.smallBlind}/${s.bigBlind}`} – {s.duration} min
              </Text>
              <Button title="🗑️" color="#c00" onPress={() => removeLevel(i)} />
            </View>
          ))}
        </View>
      )}

      <Text style={styles.section}>🧩 Extras</Text>
      <TextInput style={styles.input} placeholder="Starting Chips" value={startingChips} onChangeText={setStartingChips} keyboardType="numeric" />
      <TextInput style={styles.input} placeholder="Game Type" value={gameType} onChangeText={setGameType} />
      <TextInput style={styles.input} placeholder="Prize Pool (optional)" value={prizePool} onChangeText={setPrizePool} keyboardType="numeric" />
      <TextInput style={styles.input} placeholder="Late Registration (levels)" value={lateRegistrationLevels} onChangeText={setLateRegistrationLevels} keyboardType="numeric" />
      <TextInput style={styles.input} placeholder="Re-Entries Allowed" value={reentriesAllowed} onChangeText={setReentriesAllowed} keyboardType="numeric" />

      <View style={styles.switchRow}>
        <Text>Bounty Tournament?</Text>
        <Switch value={isBounty} onValueChange={setIsBounty} />
      </View>
      {isBounty && (
        <TextInput style={styles.input} placeholder="Bounty Amount (£)" value={bountyAmount} onChangeText={setBountyAmount} keyboardType="numeric" />
      )}

      <Button title="Save Changes" onPress={handleSubmit} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#fff',
  },
  section: {
    fontWeight: 'bold',
    fontSize: 16,
    marginVertical: 12,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 10,
    marginBottom: 10,
  },
  structureList: {
    marginVertical: 10,
    backgroundColor: '#f3f3f3',
    padding: 10,
    borderRadius: 6,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
  },
});
