const express = require('express');
const Casino = require('../models/Casino');
const auth = require('../middleware/auth');
const requireStaff = require('../middleware/requireStaff');
const router = express.Router();

// List casinos (public)
router.get('/', async (_req, res) => {
  const casinos = await Casino.find().lean();
  res.json(casinos);
});

// Create casino (staff/admin only)
router.post('/', auth, requireStaff, async (req, res) => {
  try {
    const { name, city, country, location } = req.body;
    if (!name) return res.status(400).json({ error: 'Name required' });
    const casino = await Casino.create({ name, city, country, location });
    res.status(201).json(casino);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create casino' });
  }
});

// Update casino (staff/admin only, and must be in assignedCasinoIds unless admin)
router.put('/:id', auth, requireStaff, async (req, res) => {
  try {
    const { id } = req.params;
    if (req.user.role !== 'admin' && !req.user.assignedCasinoIds.includes(id)) {
      return res.status(403).json({ error: 'Not assigned to this casino' });
    }
    const updated = await Casino.findByIdAndUpdate(id, req.body, { new: true });
    if (!updated) return res.status(404).json({ error: 'Casino not found' });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: 'Failed to update casino' });
  }
});

// Delete casino (admin only)
router.delete('/:id', auth, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  const deleted = await Casino.findByIdAndDelete(req.params.id);
  if (!deleted) return res.status(404).json({ error: 'Casino not found' });
  res.json({ ok: true });
});

module.exports = router;
