import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  Button,
  ActivityIndicator,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function CasinoDetailScreen({ route, navigation }) {
  const { casino } = route.params;
  const [data, setData] = useState(casino);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState({ role: null, casinoId: null });

  useEffect(() => {
    const fetchUserAndCasino = async () => {
      const role = await AsyncStorage.getItem('role');
      const assignedCasinoId = await AsyncStorage.getItem('casinoId');
      setUser({ role, casinoId: assignedCasinoId });

      try {
        const res = await fetch(`http://192.168.0.180:5000/api/casinos/${casino._id}`);
        const text = await res.text();

        try {
          const updated = JSON.parse(text);
          setData(updated);
        } catch (e) {
          console.error('Error parsing JSON:', text);
        }
      } catch (err) {
        console.error('Error fetching casino:', err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUserAndCasino();
    const unsubscribe = navigation.addListener('focus', fetchUserAndCasino);
    return unsubscribe;
  }, [navigation]);

  const renderTournament = ({ item }) => (
    <TouchableOpacity
      style={styles.previewCard}
      onPress={() =>
        navigation.navigate('TournamentDetail', {
          tournament: JSON.parse(JSON.stringify(item)),
          casinoName: data.name,
          casinoId: data._id,
        })
      }
    >
      <Text style={styles.title}>{item.name}</Text>
      <Text style={styles.line}>Buy-In: £{item.buyIn} + £{item.rake}</Text>
      <Text style={styles.line}>Start: {new Date(item.date).toLocaleString()}</Text>
      {item.prizePool && <Text style={styles.line}>Prize Pool: £{item.prizePool}</Text>}
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
        <Text>Loading casino details...</Text>
      </View>
    );
  }

  console.log('🧠 Role:', user.role);
  console.log('🏛️ Assigned Casino ID:', user.casinoId);
  console.log('📍 Viewing Casino ID:', data._id);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.headerBox}>
        <Text style={styles.header}>{data.name}</Text>
        <Text style={styles.address}>{data.address}</Text>
      </View>

      {user.role === 'staff' && user.casinoId === data._id && (
        <View style={styles.buttonWrapper}>
          <Button
            title="➕ Add Tournament"
            onPress={() => navigation.navigate('AddTournament', { casinoId: data._id })}
            color="#2196F3"
          />
        </View>
      )}

      {data.tournaments.length === 0 ? (
        <Text style={styles.noTournaments}>No tournaments available.</Text>
      ) : (
        <FlatList
          data={data.tournaments}
          keyExtractor={(item, index) => index.toString()}
          renderItem={renderTournament}
          scrollEnabled={false}
        />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#f9f9f9',
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerBox: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 10,
    marginBottom: 12,
    elevation: 3,
  },
  header: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  address: {
    fontSize: 14,
    color: '#666',
  },
  buttonWrapper: {
    marginBottom: 16,
  },
  noTournaments: {
    fontStyle: 'italic',
    color: '#666',
    textAlign: 'center',
    marginTop: 20,
  },
  previewCard: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 10,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 6,
  },
  line: {
    fontSize: 14,
    color: '#444',
  },
});
